Ex0

this project is about undirected  graphs.

dataStructure:
the data structure of undirected  graph, can add nodes, delete nodes, connect nodes, get a specific node/edge,
for nodes in graph i used a data structer "HashMap "(time complexety of add and get its O(1)) anf for neghbors in node used "Hashset"

algorithms:

shortestPathDist, isconnected,shortestPath-used algoritm of BFS(time compexety is O(V+E))

